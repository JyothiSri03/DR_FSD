import './App.css';
import EmployeeData from './task'
function App() {
  return (
    <div className="App">
    <EmployeeData/>
    </div>
  );
}

export default App;
