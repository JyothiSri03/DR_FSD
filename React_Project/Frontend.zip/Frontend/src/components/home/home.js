import ImageShow from "./imageshow";
function Home()
{
    return(
        <>
        <div className='container-fluid'>
        <br/><br/><br/><br/>
            <ImageShow/>
        </div>
        </>
    )
}
export default Home;